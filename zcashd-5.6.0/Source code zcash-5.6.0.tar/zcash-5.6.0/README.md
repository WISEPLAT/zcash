### Zcash builder for Zecwallet

This is a collection of scripts to build the embedded zcash daemon for the Zecwallet Fullnode wallet. It builds directly from ECC's zcash repository. 